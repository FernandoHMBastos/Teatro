//
//  PecaViewController.h
//  Teatro
//
//  Created by Gabarron on 25/03/15.
//  Copyright (c) 2015 Fernando H M Bastos. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSON.h"
#import "Peca.h"

@interface PecaViewController : UIViewController

///Utiliza a classe Peca
@property (nonatomic, strong) Peca *peca;

@end
