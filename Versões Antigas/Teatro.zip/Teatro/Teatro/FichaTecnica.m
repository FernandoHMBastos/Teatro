//
//  FichaTecnica.m
//  Teatro
//
//  Created by Vítor Machado Rocha on 26/03/15.
//  Copyright (c) 2015 Fernando H M Bastos. All rights reserved.
//

#import "FichaTecnica.h"


@interface FichaTecnica ()


@end

@implementation FichaTecnica



@end
