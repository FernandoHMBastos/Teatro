//
//  Destaques.h
//  Teatro
//
//  Created by Gabarron on 31/03/15.
//  Copyright (c) 2015 Fernando H M Bastos. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Destaques : NSObject

-(void) destaques;

@property(nonatomic, strong) NSMutableArray *listaDestaques;
@property(nonatomic, strong) NSMutableArray *mutableSortedArray;

@end
