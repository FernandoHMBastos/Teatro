//
//  DestaquesVC.h
//  Teatro
//
//  Created by Gabarron on 31/03/15.
//  Copyright (c) 2015 Fernando H M Bastos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DestaquesVC : UIViewController <UITableViewDataSource, UITableViewDelegate>

@end
