//
//  listaTableViewCell.m
//  Teatro
//
//  Created by Vítor Machado Rocha on 30/03/15.
//  Copyright (c) 2015 Fernando H M Bastos. All rights reserved.
//

#import "listaTableViewCell.h"

@implementation listaTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
