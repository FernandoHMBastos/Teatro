//
//  DestaquesTableViewCell.m
//  Teatro
//
//  Created by Gabarron on 31/03/15.
//  Copyright (c) 2015 Fernando H M Bastos. All rights reserved.
//

#import "DestaquesTableViewCell.h"

@implementation DestaquesTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
